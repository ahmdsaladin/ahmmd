<?php
if ( ! function_exists( "axtra_add_metaboxes" ) ) {
	function axtra_add_metaboxes( $metaboxes ) {
		$directories_array = array(
			'page.php',
			'projects.php',
			'service.php',
			'team.php',
			'testimonials.php',
			'career.php',
		);
		foreach ( $directories_array as $dir ) {
			$metaboxes[] = require_once( AXTRAPLUGIN_PLUGIN_PATH . '/metabox/' . $dir );
		}

		return $metaboxes;
	}

	add_action( "redux/metaboxes/axtra_options/boxes", "axtra_add_metaboxes" );
}

