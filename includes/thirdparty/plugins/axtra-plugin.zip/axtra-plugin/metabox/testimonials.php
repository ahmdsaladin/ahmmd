<?php
return array(
	'title'      => 'Axtra Testimonials Setting',
	'id'         => 'axtra_meta_testimonials',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'testimonials' ),
	'sections'   => array(
		array(
			'id'     => 'axtra_testimonials_meta_setting',
			'fields' => array(
				array(
					'id'    => 'author_feedback',
					'type'  => 'text',
					'title' => esc_html__( 'Author FeedBack', 'axtra' ),
				),
				array(
					'id'    => 'author_name',
					'type'  => 'text',
					'title' => esc_html__( 'Author Name', 'axtra' ),
				),
				array(
					'id'    => 'author_designation',
					'type'  => 'text',
					'title' => esc_html__( 'Author Designation', 'axtra' ),
				),
			),
		),
	),
);